﻿using System;
using System.Collections.Generic;
using System.Text;

namespace adapter_ooad
{
    class Expense
    {
        private string Descr;
        private double Amount;
        public string descr
        {
            get { return Descr; }
        }
        public double amount
        {
            get { return Amount; }
        }
        public string get_info()
        {
            return Descr + ";" + amount.ToString();
        }
        public Expense(string d,double a)
        {
            this.Descr = d;
            this.Amount = a;
        }
    }
}
