﻿using System;
using System.Collections.Generic;
using System.Text;

namespace adapter_ooad
{
    class person:IObject
    {
        private string Name;
        private int Age;
        public string name
        {
            get { return Name; }
        
        }
        public int age
        {
            get { return Age; }
    
        }

        public string info()
        {
            return string.Format("Name={0};Age={1}", name, age);
            throw new NotImplementedException();
        }

        public string type()
        {
            return "Person";
            throw new NotImplementedException();
        }
        public person(int a,string n)
        {
            this.Age = a;
            this.Name = n;
        }
    }
}
