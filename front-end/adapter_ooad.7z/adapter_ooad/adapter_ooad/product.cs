﻿using System;
using System.Collections.Generic;
using System.Text;

namespace adapter_ooad
{
    class product:IObject
    {
        private string Id;
        private string Name;
        private double Price;
        public string id
        {
            get { return Id; }
        }
        public string name
        {
            get { return Name; }
        }
        public Double price
        {
            get { return price; }
        }

        public string info()
        {
            return string.Format("Id={0};Name={1};Price= "+Price.ToString(), id, name);
            throw new NotImplementedException();
        }

        public string type()
        {
            return "Product"; 
            throw new NotImplementedException();
        }
        public product(string i,string n,double p)
        {
            this.Id = i;
            this.Name = n;
            this.Price = p;
        }
    }
}
