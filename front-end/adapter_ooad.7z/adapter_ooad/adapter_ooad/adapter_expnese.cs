﻿using System;
using System.Collections.Generic;
using System.Text;

namespace adapter_ooad
{
    class adapter_expnese : IObject
    {
        private Expense e;
        public Expense E
        { 
            get{return e;}
        }

        public string info()
        {
            return e.get_info();
            throw new NotImplementedException();
        }

        public string type()
        {
            return "Expense";
            throw new NotImplementedException();
        }
        public adapter_expnese(Expense ex)
        {
            this.e = ex;
        }
    }
}
