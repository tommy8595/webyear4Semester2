﻿using System;
using System.Collections.Generic;
using System.Text;

namespace adapter_ooad
{
    interface IObject
    {
        string type();
        string info();
    }
}
