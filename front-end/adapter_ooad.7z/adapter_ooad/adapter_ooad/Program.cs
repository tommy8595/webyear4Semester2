﻿using System;
using System.Collections.Generic;

namespace adapter_ooad
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IObject> e = new List<IObject>();
            e.Add(new person(12, "Oudome"));
            e.Add(new product("1", "Coca", 2));
            Expense ex = new Expense("Jong dai", 20);
            e.Add(new adapter_expnese(ex));
            foreach(IObject t in e)
            {
                Console.WriteLine(t.type() + t.info());
            }
            Console.Read();
        }
    }
}
